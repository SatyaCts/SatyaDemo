# jenkinsfiles
Examples collected for Jenkins files from www


